# ساخت APK در فضای ابری GitHub Actions

این پروژه حالا workflow ساخت خودکار APK را در مسیر `.github/workflows/build-apk.yml` دارد. برای دریافت APK باید پروژه در یک repository گیت‌هاب بارگذاری شود و workflow اجرا گردد.

1. در GitHub یک repository جدید بسازید.
2. تمام محتویات این پوشه را در repository بارگذاری کنید.
3. به بخش **Actions** بروید و workflow با نام **Build Aflatoon APK** را انتخاب کنید.
4. روی **Run workflow** بزنید.
5. پس از موفقیت، از همان اجرای workflow بخش **Artifacts** فایل `Aflatoon-debug-apk` را دریافت کنید و ZIP مربوط به artifact را باز کنید تا APK داخلش باشد.

توجه: این workflow فقط APK آزمایشی (debug) می‌سازد؛ امضای انتشار (release) جداگانه نیاز دارد. موفقیت ساخت تا وقتی workflow اجرا نشده تضمین نیست. همچنین ساخت APK به معنای تکمیل موتور هوش مصنوعی آفلاین نیست؛ موتور مدل هنوز باید پیاده‌سازی شود.
