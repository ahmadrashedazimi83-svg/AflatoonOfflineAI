package com.aflatoon.offlineai

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.Manifest
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings

/** Small, explicit allow-list of Android actions. Never executes arbitrary shell commands. */
class DeviceCommandRouter(private val activity: Activity) {
    data class Result(val handled: Boolean, val message: String)

    fun handle(raw: String): Result {
        val text = raw.trim().lowercase()
        if (text.isBlank()) return Result(false, "")
        return when {
            containsAny(text, "تنظیمات", "settings") -> open(Intent(Settings.ACTION_SETTINGS), "تنظیمات تیلفون باز شد.")
            containsAny(text, "وای فای", "وای‌فای", "wifi", "wi-fi", "شبکه") -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) open(Intent(Settings.Panel.ACTION_WIFI), "صفحهٔ وای‌فای باز شد؛ از همان‌جا وصل شو.")
                else open(Intent(Settings.ACTION_WIFI_SETTINGS), "تنظیمات وای‌فای باز شد؛ از همان‌جا وصل شو.")
            }
            containsAny(text, "بلوتوث", "bluetooth") -> open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "تنظیمات بلوتوث باز شد.")
            containsAny(text, "چراغ قوه خاموش", "چراغ‌قوه خاموش", "فلاش خاموش", "flashlight off", "torch off") -> toggleFlashlight(false)
            containsAny(text, "چراغ قوه", "چراغ‌قوه", "فلاش", "flashlight", "torch") -> toggleFlashlight(true)
            containsAny(text, "واتساپ", "whatsapp") -> launchApp("com.whatsapp", "واتساپ")
            containsAny(text, "یوتیوب", "youtube") -> launchApp("com.google.android.youtube", "یوتیوب")
            containsAny(text, "مرورگر", "کروم", "chrome", "browser", "اینترنت را باز") -> open(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")), "مرورگر باز شد.")
            containsAny(text, "تماس بگیر", "زنگ بزن", "شماره گیری", "شماره‌گیری", "تماس با") -> askBeforeCall(raw)
            containsAny(text, "آلارم", "زنگ بیداری", "ساعت بیداری", "alarm") -> setAlarm()
            containsAny(text, "بلندی صدا", "تنظیم صدا", "volume") -> open(Intent("android.settings.SOUND_SETTINGS"), "تنظیمات صدا باز شد.")
            containsAny(text, "باتری", "مصرف باتری") -> open(Intent(Intent.ACTION_POWER_USAGE_SUMMARY), "صفحهٔ مصرف باتری باز شد.")
            else -> Result(false, "")
        }
    }

    private fun toggleFlashlight(turnOn: Boolean): Result {
        if (activity.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            activity.requestPermissions(arrayOf(Manifest.permission.CAMERA), 4102)
            return Result(true, "برای کنترول چراغ‌قوه اجازهٔ دوربین لازم است؛ اجازه را بده و دستور را دوباره بگو.")
        }
        return try {
            val manager = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return Result(true, "این تیلفون چراغ‌قوهٔ قابل‌کنترول پیدا نکرد.")
            // Android does not expose the current torch state consistently; use a safe on action.
            manager.setTorchMode(cameraId, turnOn)
            Result(true, if (turnOn) "چراغ‌قوه روشن شد." else "چراغ‌قوه خاموش شد.")
        } catch (_: Exception) {
            Result(true, "نتوانستم چراغ‌قوه را روشن کنم؛ ممکن است دوربین در حال استفاده باشد یا این قابلیت پشتیبانی نشود.")
        }
    }

    private fun launchApp(packageName: String, label: String): Result {
        val launch = activity.packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) return try {
            activity.startActivity(launch)
            Result(true, "$label باز شد.")
        } catch (_: Exception) { Result(true, "بازکردن $label ممکن نشد.") }
        return Result(true, "$label نصب نیست یا اندروید اجازهٔ پیدا کردن آن را نمی‌دهد.")
    }

    private fun askBeforeCall(raw: String): Result {
        val number = Regex("(?:\\+?\\d[\\d ()-]{5,}\\d)").find(raw)?.value?.replace(Regex("[^+0-9]"), "")
        if (number.isNullOrBlank()) return Result(true, "برای تماس، شماره را هم بنویس؛ مثلاً «با 0790000000 تماس بگیر». تماس فقط بعد از تأیید تو در صفحهٔ شماره‌گیر آغاز می‌شود.")
        activity.runOnUiThread {
            AlertDialog.Builder(activity)
                .setTitle("تأیید تماس")
                .setMessage("صفحهٔ شماره‌گیر را با این شماره باز کنم؟\n$number")
                .setNegativeButton("لغو", null)
                .setPositiveButton("ادامه") { _, _ ->
                    try { activity.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))) }
                    catch (_: Exception) { }
                }.show()
        }
        return Result(true, "برای ادامه، درخواست تماس را در پنجرهٔ تأیید کن.")
    }

    private fun setAlarm(): Result {
        return try {
            val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS)
            activity.startActivity(intent)
            Result(true, "برنامهٔ ساعت و آلارم باز شد؛ وقت آلارم را انتخاب کن.")
        } catch (_: Exception) { Result(true, "برنامهٔ ساعت در این تیلفون در دسترس نیست.") }
    }

    private fun open(intent: Intent, success: String): Result = try {
        activity.startActivity(intent)
        Result(true, success)
    } catch (_: Exception) {
        Result(true, "این صفحه در تیلفون در دسترس نیست یا توسط سازنده محدود شده است.")
    }

    private fun containsAny(text: String, vararg terms: String) = terms.any { text.contains(it) }
}
