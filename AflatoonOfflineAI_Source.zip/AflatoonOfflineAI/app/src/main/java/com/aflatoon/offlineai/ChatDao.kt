package com.aflatoon.offlineai

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete

@Dao
interface ChatDao {
    @Query("SELECT * FROM messages ORDER BY createdAt ASC")
    suspend fun all(): List<ChatMessage>

    @Insert
    suspend fun insert(message: ChatMessage)

    @Query("DELETE FROM messages")
    suspend fun clear()
}
