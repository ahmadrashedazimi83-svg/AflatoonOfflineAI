package com.aflatoon.offlineai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var db: ChatDatabase
    private lateinit var engine: OfflineModelEngine
    private lateinit var router: DeviceCommandRouter
    private lateinit var messagesBox: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var speech: SpeechRecognizer? = null
    private var lastAnswer = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ChatDatabase.get(this)
        engine = OfflineModelEngine()
        router = DeviceCommandRouter(this)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 14)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val header = TextView(this).apply {
            text = "افلاطون  •  دستیار شخصی"
            textSize = 22f; gravity = Gravity.CENTER
            setTextColor(0xFF172033.toInt()); setPadding(0, 8, 0, 4)
        }
        val subtitle = TextView(this).apply {
            text = "دستورات تیلفون + تاریخچهٔ گفت‌وگو"
            textSize = 13f; gravity = Gravity.CENTER
            setTextColor(0xFF536176.toInt()); setPadding(0, 0, 0, 12)
        }
        messagesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(messagesBox) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "دستور یا سؤال خود را بنویس…"
            minLines = 1; maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
        }
        val mic = Button(this).apply { text = "🎙"; contentDescription = "گفتن دستور" }
        val send = Button(this).apply { text = "اجرا" }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(mic)
        row.addView(send)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val speak = Button(this).apply { text = "🔊 خواندن پاسخ" }
        val clear = Button(this).apply { text = "پاک‌کردن تاریخچه" }
        bottom.addView(speak, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(clear, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header); root.addView(subtitle)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row); root.addView(bottom)
        setContentView(root)

        send.setOnClickListener { sendMessage() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE) { sendMessage(); true } else false
        }
        mic.setOnClickListener { startVoiceInput() }
        speak.setOnClickListener {
            if (lastAnswer.isNotBlank()) tts.speak(lastAnswer, TextToSpeech.QUEUE_FLUSH, null, "aflatoon-answer")
            else Toast.makeText(this, "هنوز پاسخی برای خواندن نیست.", Toast.LENGTH_SHORT).show()
        }
        clear.setOnClickListener {
            lifecycleScope.launch { db.chatDao().clear(); runOnUiThread { messagesBox.removeAllViews(); lastAnswer = "" } }
        }
        lifecycleScope.launch {
            db.chatDao().all().forEach {
                addBubble(it.role, it.content)
                if (it.role == "assistant") lastAnswer = it.content
            }
            addBubble("assistant", "سلام! می‌توانی بگویی «تنظیمات را باز کن»، «وای‌فای را باز کن»، «چراغ‌قوه روشن/خاموش»، «واتساپ را باز کن» یا «با شمارهٔ ... تماس بگیر». تماس با تأیید تو باز می‌شود. برای چت هوش مصنوعی کاملاً آفلاین هنوز باید مدل زبانی واقعی به پروژه افزوده شود.")
        }
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        addBubble("user", text)
        lifecycleScope.launch {
            db.chatDao().insert(ChatMessage(role = "user", content = text))
            val command = router.handle(text)
            val answer = if (command.handled) command.message else try {
                engine.generate(text)
            } catch (_: Exception) {
                "دستور مشخصی برای کنترول تیلفون از این جمله تشخیص نشد. می‌توانی از نمونه‌های بالای صفحه استفاده کنی. موتور گفت‌وگوی هوش مصنوعی آفلاین هنوز به مدل واقعی نیاز دارد؛ این پروژه فعلاً آن مدل را همراه ندارد."
            }
            db.chatDao().insert(ChatMessage(role = "assistant", content = answer))
            runOnUiThread { lastAnswer = answer; addBubble("assistant", answer) }
        }
    }

    private fun addBubble(role: String, text: String) {
        val tv = TextView(this).apply {
            this.text = (if (role == "user") "شما: " else "افلاطون: ") + text
            textSize = 16f
            setTextColor(0xFF182230.toInt())
            setPadding(15, 12, 15, 12)
            setBackgroundColor(if (role == "user") 0xFFDCEBFF.toInt() else 0xFFFFFFFF.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) }
        messagesBox.addView(tv, lp)
    }

    private fun startVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 4101)
            Toast.makeText(this, "اجازهٔ میکروفون را بده و دوباره دکمهٔ صدا را بزن.", Toast.LENGTH_LONG).show()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "تشخیص گفتار در این گوشی در دسترس نیست.", Toast.LENGTH_LONG).show(); return
        }
        speech?.destroy()
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (words != null) { input.setText(words); input.setSelection(words.length) }
            }
            override fun onError(error: Int) { Toast.makeText(this@MainActivity, "تشخیص صدا انجام نشد؛ ممکن است اینترنت یا بستهٔ زبان لازم باشد.", Toast.LENGTH_LONG).show() }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-AF")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-AF")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "حالا دستور خود را بگو")
        }
        try { speech?.startListening(intent) }
        catch (_: Exception) { Toast.makeText(this, "شروع تشخیص گفتار ممکن نشد.", Toast.LENGTH_SHORT).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "اجازه داده شد؛ دستور را دوباره اجرا کن.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("fa", "AF"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale("fa", "IR")
            }
        }
    }
    override fun onDestroy() {
        speech?.destroy()
        tts.stop(); tts.shutdown()
        super.onDestroy()
    }
}
