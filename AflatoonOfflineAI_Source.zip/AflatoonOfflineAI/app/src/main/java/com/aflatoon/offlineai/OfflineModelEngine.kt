package com.aflatoon.offlineai

/**
 * Adapter boundary for the on-device language model.
 *
 * Intentionally fails clearly until a compatible model and matching MediaPipe API
 * version are selected. This avoids pretending that model inference works without
 * shipping a compatible model file.
 */
class OfflineModelEngine {
    fun isReady(): Boolean = false

    suspend fun generate(prompt: String): String {
        throw IllegalStateException(
            "مدل آفلاین نصب نشده است. باید مدل سازگار .task و اتصال موتور MediaPipe اضافه شود."
        )
    }
}
